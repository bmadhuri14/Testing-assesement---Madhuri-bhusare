package GithubTask;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

public class Login {
	
	WebDriver driver;
	
	@BeforeMethod()
	public void beforeMethod()
	{
		driver = new ChromeDriver();
		driver.get("https://sakshingp.github.io/assignment/login.html");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
	}
	
	@AfterMethod
	public void afterMethod()
	{
		driver .quit();
		
	}
	
	@Test
	public void TC_01_Title_check() throws Exception
	{
		
		String Act_title = driver.getTitle();
		System.out.println("Act_title->"+Act_title);
		
		File file = new File ("C:\\Users\\Madhuri Bhusare\\OneDrive\\github_Login_TC.xls");
		Workbook workbook = Workbook.getWorkbook(file);
		jxl.Sheet sheet = workbook.getSheet("Sheet1");
		Cell cell = sheet.getCell(5,4);
		String Exp_title = cell.getContents();
		System.out.println("Exp_title->"+Exp_title);
		
		Assert.assertEquals(Act_title, Exp_title);
		
	}
	
	@Test
	public void TC_02_Url_Check() throws Exception 
	{
		
		String Act_Url = driver.getCurrentUrl();
		System.out.println("Act_Url->"+Act_Url);

		File file = new File("C:\\Users\\Madhuri Bhusare\\OneDrive\\github_Login_TC.xls");
		Workbook workbook = Workbook.getWorkbook(file);
		jxl.Sheet sheet = workbook.getSheet("Sheet1");
		Cell cell = sheet.getCell(5, 5);
		String Exp_Url = cell.getContents();
		System.out.println("Exp_Url->"+Exp_Url);

		Assert.assertEquals(Act_Url, Exp_Url);
	}	
		
	@Test
	public void TC_03_ValUsername_InvPassCheck() throws Exception 
	{
		
		driver.findElement(By.id("Username")).sendKeys("Madhu");
		driver.findElement(By.id("password")).sendKeys("12345");
		driver.findElement(By.xpath("//*[@id=\"form\"]/div[3]/div/button")).click();                          
	                 

		WebElement Act_Res = driver.findElement(By.xpath("/html/body/div/div[2]/form/div[2]/div"));
		System.out.println("Act_Res->"+ Act_Res.getText());

		File file = new File("C:\\Users\\Madhuri Bhusare\\Downloads\\Login_TC_Test_NG.xls");
		Workbook workbook = Workbook.getWorkbook(file);
		jxl.Sheet sheet = workbook.getSheet("Sheet1");
		Cell cell = sheet.getCell(5, 6);
		String Exp_Res = cell.getContents();
		System.out.println("Exp_Res->"+ Exp_Res);

		Assert.assertEquals(Act_Res.getText(), Exp_Res);
	}
	@Test
	public void TC_04_twitter_button() throws Exception, IOException {
		 driver.findElement(By.xpath("/html/body/div/div/form/div[3]/div[2]/a[1]/img")).click();
		 String Act_result = null;
		 System.out.println("Act_result ->" + Act_result);
		 
		 File file = new File("C:\\Users\\Madhuri Bhusare\\OneDrive\\github_Login_TC.xls");
		 Workbook workbook = Workbook.getWorkbook(file);
		 Sheet sheet = workbook.getSheet("Sheet1");
		 Cell cell = sheet.getCell(5, 16);
		 String Exp_result = cell.getContents();
		 System.out.println("Exp_result ->" + Exp_result);
		 
		 Assert.assertEquals(Act_result, Exp_result);
	}
	
	
	@Test
	public void TC_05_facebook_button() throws Exception, IOException {
		 driver.findElement(By.xpath("/html/body/div/div/form/div[3]/div[2]/a[2]/img")).click();
		 String Act_result = null;
		 System.out.println("Act_result ->" + Act_result);
		 
		 File file = new File("C:\\Users\\Madhuri Bhusare\\OneDrive\\github_Login_TC.xls");
		 Workbook workbook = Workbook.getWorkbook(file);
		 Sheet sheet = workbook.getSheet("Sheet1");
		 Cell cell = sheet.getCell(5, 17);
		 String Exp_result = cell.getContents();
		 System.out.println("Exp_result ->" + Exp_result);
		 
		 Assert.assertEquals(Act_result, Exp_result);
	}
	
	@Test
	public void TC_06_linkedin_button() throws Exception, IOException {
		 driver.findElement(By.xpath("/html/body/div/div/form/div[3]/div[2]/a[3]/img")).click();
		 String Act_result = null;
		 System.out.println("Act_result ->" + Act_result);
		 
		 File file = new File("C:\\Users\\Madhuri Bhusare\\OneDrive\\github_Login_TC.xls");
		 Workbook workbook = Workbook.getWorkbook(file);
		 Sheet sheet = workbook.getSheet("Sheet1");
		 Cell cell = sheet.getCell(5, 18);
		 String Exp_result = cell.getContents();
		 System.out.println("Exp_result ->" + Exp_result);
		 
		 Assert.assertEquals(Act_result, Exp_result);
	}
	
	@Test
	public void TC_07_directly_click_on_login_button() throws Exception, IOException {
		 driver.findElement(By.xpath("/html/body/div/div/form/div[3]/button")).click();
		 WebElement Act_result = driver.findElement(By.xpath("/html/body/div/div/div[3]"));
		 System.out.println("Act_result ->" + Act_result.getText());
		 
		 File file = new File("C:\\Users\\Madhuri Bhusare\\OneDrive\\github_Login_TC.xls");
		 Workbook workbook = Workbook.getWorkbook(file);
		 Sheet sheet = workbook.getSheet("Sheet1");
		 Cell cell = sheet.getCell(5, 10);
		 String Exp_result = cell.getContents();
		 
		    
			
		 
		 System.out.println("Exp_result ->" + Exp_result);
		 
		 Assert.assertEquals(Act_result.getText(), Exp_result);
	}
	
	
}

	
package GithubTask;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class tra {

    public static void main(String[] args) {
        
    	 System.setProperty("webdriver.Chrome.driver", "ChromeDriver.exe");
    	 
        
        WebDriver driver = new ChromeDriver();
        driver.get("https://sakshingp.github.io/assignment/login.html");

        
        List<Double> numericValues = new ArrayList<>();
        numericValues.add(1250.00);
        numericValues.add(952.23);
        numericValues.add(-320.00);
        numericValues.add(17.99);
        numericValues.add(-244.00);
        numericValues.add(340.00);

        
        System.out.println("Original List: " + numericValues);

        
        Collections.sort(numericValues);

        
        System.out.println("Sorted List (Ascending Order): " + numericValues);

        
        driver.quit();
    }
}

